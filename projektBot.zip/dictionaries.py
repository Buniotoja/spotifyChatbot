keywords={
    1: ["album", "płyt"],
    2: ["artyst", "wykona", "kto", "Kto", "gwiazd", "twórc", "autor", "czyj", "Czyj", "skompon"],
    3: ["kawał", "utw", "piosen", "numer", "przeb", "hit"],
}
user_options={
    1: "album",
    2: "artysta",
    3: "utwór"
}
user_options_pol={
    "album": "album",
    "artist": "artysta",
    "track": "utwór"
}